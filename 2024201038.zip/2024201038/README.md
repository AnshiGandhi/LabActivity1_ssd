Assuming that all the files are in same folder, run the .sh file using ./file_name.sh command on terminal and the output will be displayed.

./2024201038_q1.sh
./2024201038_q2.sh

input for q1 is in file access.log
input for q2 is in file power_levels.txt
